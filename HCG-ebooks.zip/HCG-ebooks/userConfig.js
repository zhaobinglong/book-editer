var bcUserInfo = {
	"uId": 29308,
	"uLink": "img",
	"uType": 1,
	"name": "baige",
	"about": "",
	"website": "",
	"accountLogo": "\/\/book.yunzhan365.com\/olze\/accountlogo.jpg",
	"domain": "",
	"domainSuffix": "",
	"customType": 0
}