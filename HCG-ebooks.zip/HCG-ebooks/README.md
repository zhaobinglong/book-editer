## 运行
```
browser-sync start --server --files "**/*"
```

## 访问
http://localhost:3000/index.htm